package com.example.tictactoowebapp;

import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    WebView webView;
    ImageView nojimaLogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nojimaLogo = findViewById(R.id.nojimaLogo);
        webView = findViewById(R.id.webview);

        // Hide WebView initially
        webView.setVisibility(View.INVISIBLE);

        // Show splash logo for 2 seconds, then show WebView
        new Handler().postDelayed(() -> {
            nojimaLogo.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new WebViewClient());
            webView.loadUrl("file:///android_asset/index.html");
        }, 2000);
    }
}
